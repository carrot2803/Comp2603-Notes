import java.awt.Color;
public class ShapeRunner{
   public static void main(String[] args){
     ShapeScreen s = new ShapeScreen();
    
   }
}
