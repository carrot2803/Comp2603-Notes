public class Grove{
    private static int groveIDCounter = 100;
    private int groveID;
    private String name;
    
    public Grove(String name){
        this.name = name;
        groveID = groveIDCounter;
        groveIDCounter = groveIDCounter + 100;
    }
    
    public String toString(){
        return "Grove " + groveID + " " + name;
    }
    
    public void setGroveID(int groveID){
        this.groveID = groveID;
    }
    
    public boolean equals(Object obj){
        if(obj instanceof Grove){
            Grove g = (Grove)obj;
            return this.groveID == g.groveID;
        }
        throw new IllegalArgumentException ("cannot compare non-Grove objects");
    }
}