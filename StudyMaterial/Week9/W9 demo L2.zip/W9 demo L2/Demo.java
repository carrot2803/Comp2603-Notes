import java.util.HashMap;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;
public class Demo{
   private static Map<Plant,Grove> orchard = getTreeMap();
    
   public static void main(String[] args){ 
     prettyPrint(orchard);
     Plant key1 = new Plant("Hibiscus");
     mapUpdateKeyDemo(key1);   
     Plant key2 = new Plant("Blood Orange");
     mapUpdateKeyDemo(key2);
   }
   public static void mapUpdateKeyDemo(Plant key){
     
   }
   public static void mapUpdateValueDemo(Grove value){
     
   }
   
   public static void mapRemoveKeyDemo(Plant key){
       if(orchard.containsKey(key))
            orchard.remove(key);
        prettyPrint(orchard); 
   }
   
   public static void mapRemoveValueDemo(Grove value){   
        if(orchard.containsValue(value)){
            for(Map.Entry<Plant, Grove> key_value : orchard.entrySet()){
                if(key_value.getValue().equals(value)){ 
                    Plant key = key_value.getKey();
                    orchard.remove(key, value);
                    break;
                }
            }
            prettyPrint(orchard); 
            System.out.println("REMOVED " + value +" AND KEY ");
        }
        else
            System.out.println("CANNOT REMOVE. VALUE NOT IN MAP " + value);
   }
   
   
   public static void mapFindKeyDemo(Grove value){
        prettyPrint(orchard);
        Plant key = null;
        if(!orchard.containsValue(value))
            System.out.println("KEY NOT FOUND FOR "+ value);
        else{  
           
            for(Map.Entry<Plant, Grove> key_value : orchard.entrySet()){
                Grove storedValue = key_value.getValue();
                if(storedValue.equals(value)){ 
                    key = key_value.getKey();
                    System.out.println("KEY FOUND FOR "+ value + " -> "+ key);
                    break;
                }
            }
        }
   }
    
    
   public static void mapFindValueDemo(Plant key){
        prettyPrint(orchard);
        Grove value = null;
        if(orchard.containsKey(key))
            value = orchard.get(key);
        if(value == null) System.out.println("VALUE NOT FOUND FOR "+ key);
        else  System.out.println("VALUE FOUND FOR "+ key + " -> "+ value);
    }
   
   public static TreeMap<Plant,Grove> getTreeMap(){
        String[] plantNames = {"Pineapple Orange","Blood Orange",
                                "Valencia Orange","Tangerine","Clementine"};
        TreeMap<Plant,Grove> orchard = new TreeMap<>();
        //inserting 5 plants into hashmap                     
        for(int i=0; i<5; i++)
            orchard.put(new Plant(plantNames[i]), new Grove((plantNames[i])));
        return orchard;
   }
   public static HashMap<Plant,Grove> getHashMap(){
        String[] plantNames = {"Pineapple Orange","Blood Orange",
                                "Valencia Orange","Tangerine","Clementine"};
        HashMap<Plant,Grove> orchard = new HashMap<>();
        //inserting 5 plants into hashmap                     
        for(int i=0; i<5; i++)
            orchard.put(new Plant(plantNames[i]), new Grove((plantNames[i])));
        return orchard;
   }
    public static void prettyPrint(Map<Plant, Grove> map){
        System.out.println("-------ORCHARD LIST ----------------------------");
        System.out.println("Catalogue: "+ map.size() + " entries");
        for(Plant key: map.keySet()){
            if(key.toString().length() >=19)
                System.out.println("Key: "+key + "\t Value: "+ map.get(key));
            else
               System.out.println("Key: "+key + "\t\t Value: "+ map.get(key));
        }
        System.out.println("---------------------------------------------"); 
    }
    /*
     Grove value1 = new Grove("");
     value1.setGroveID(700);
     
     Grove value2 = new Grove("");
     value2.setGroveID(400);
     
     Plant key1 = new Plant("Hibiscus");
    
     Plant key2 = new Plant("Blood Orange");
     
     
     */
}












