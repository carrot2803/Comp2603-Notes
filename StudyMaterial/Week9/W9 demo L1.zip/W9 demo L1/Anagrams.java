import java.util.*;
import java.io.*;
import java.net.*;

public class Anagrams
{
    public static void main(String[] args) throws IOException
    {
        //Data from ("http://andrew.cmu.edu/course/15-121/dictionary.txt");
        //Code from https://viterbi-web.usc.edu/~adamchik/15-121/lectures/Hashing/code/Anagrams.java
        Scanner sc = new Scanner(new File("dictionary.txt"));
        System.out.println("Loading");
        
        HashMap<String, ArrayList<String>> map =  new HashMap<String, ArrayList<String>>();
        String word;
        System.out.println("Starting");
        while( sc.hasNextLine() )
        {
            word = sc.nextLine();
            String sortedWord = sortString(word); // this is a key

            ArrayList<String> anagrams = map.get( sortedWord );  //this is a value

            if( anagrams == null ) anagrams = new ArrayList<String>();

            anagrams.add(word);
            map.put(sortedWord, anagrams);
            System.out.println(word);
        }
        System.out.println(map.get(sortString("bread")));   //testing

    }
    private static String sortString( String w )
    {
        char[] ch = w.toCharArray();
        Arrays.sort(ch);
        return new String(ch);
    }
}
