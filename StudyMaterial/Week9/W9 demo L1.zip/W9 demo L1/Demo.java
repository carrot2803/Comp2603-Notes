import java.util.HashMap;
import java.util.List;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;
public class Demo{
    public static void main(String[] args){
       hashMapDemo1();
       hashMapDemo2();
       hashMapDemo3();
       treeMapDemo4();   // will throw an exception (see explanation in week 9 L1 slides)    
    }
  
    
    public static void treeMapDemo4(){
       TreeMap<Plant,Grove> orchard = new TreeMap<>();
       Plant p1 = new Plant("Pineapple Orange");
       Plant p2 = new Plant("Blood Orange");
       Plant p3 = new Plant("Navel Orange");
       Plant p4 = new Plant("Valencia Orange");
       Plant p5 = new Plant("Tangerine");
       Plant p6 = new Plant("Clementine");
       
       Grove g1 = new Grove(p1.getName()); //"Pineapple Orange"
       orchard.put(p1,g1);
       Grove g2 = new Grove(p2.getName()); //"Blood Orange" 
       orchard.put(p2,g2);
       Grove g3 = new Grove(p3.getName()); //"Navel Orange" 
       orchard.put(p3,g3);
       prettyPrint(orchard);
    }
    
    public static void hashMapDemo3(){
       HashMap<Plant,Grove> orchard = new HashMap<>();
       Plant p1 = new Plant("Pineapple Orange");
       Plant p2 = new Plant("Pineapple Orange");
       Plant p3 = new Plant("Pineapple Orange");
       Plant p4 = new Plant("Valencia Orange");
       Plant p5 = new Plant("Tangerine");
       Plant p6 = new Plant("Clementine");
       
       Grove g1 = new Grove(p1.getName()); //"Pineapple Orange"
       orchard.put(p1,g1);
       Grove g2 = new Grove(p2.getName()); //"Blood Orange" <- used to be
       orchard.put(p2,g2);
       Grove g3 = new Grove(p3.getName()); //"Navel Orange" <- used to be
       orchard.put(p3,g3);
       prettyPrint(orchard);
    }
    
    public static void hashMapDemo2(){
        HashMap<String,List<String>> catalogue = new HashMap<>();
  
        String k1 = "Malcolm Gladwell";
        String k2 = "Daniel Keys";
        String k3 = "Steven Johnson";
        
        String[] v1 = {"What the dog saw","The Tipping Point"};
        String[] v2 = {"Flowers for Algernon"};
        String[] v3 = {"How we got to now"};

        System.out.println(catalogue.put(k1,Arrays.asList(v1)));
        System.out.println(catalogue.put(k2,Arrays.asList(v2)));
        System.out.println(catalogue.put(k3,Arrays.asList(v3)));
        
        List<String> value;
        System.out.println("-------CATALOGUE LIST -----------");
        System.out.println("Catalogue: "+ catalogue.size() + " entries");
        for(String key: catalogue.keySet()){
            value = catalogue.get(key);
            prettyPrint(key, value);
        }
        System.out.println("---------------------------------");    
    }
    public static void hashMapDemo1(){
        HashMap<String,String> catalogue = new HashMap<>();
  
        String k1 = "Malcolm Gladwell";
        String k2 = "Daniel Keys";
        String k3 = "Steven Johnson";
        
        String v1 = "What the dog saw";
        String v2 = "Flowers for Algernon";
        String v3 = "How we got to now";
        String v4 = "The Tipping Point";
        System.out.println(catalogue.put(k1,v1));
        System.out.println(catalogue.put(k2,v2));
        System.out.println(catalogue.put(k3,v3));
        
        String value;
        System.out.println("-------CATALOGUE LIST -----------");
        System.out.println("Catalogue: "+ catalogue.size() + " entries");
        for(String key: catalogue.keySet()){
            value = catalogue.get(key);
            prettyPrint(key, value);
        }
        System.out.println("---------------------------------");    
    }
    public static void prettyPrint(Map<Plant, Grove> map){
        System.out.println("-------ORCHARD LIST ----------------------------");
        System.out.println("Catalogue: "+ map.size() + " entries");
        for(Plant key: map.keySet()){
            if(key.toString().length() >19)
                System.out.println("Key: "+key + "\t Value: "+ map.get(key));
            else
               System.out.println("Key: "+key + "\t\t Value: "+ map.get(key));
        }
        System.out.println("---------------------------------------------"); 
    }
    public static void prettyPrint(String author, String book){
        if(author.length() >15)
            System.out.println("Author: "+author + "\t Book: "+ book);
        else
            System.out.println("Author: "+author + "\t\t Book: "+ book);
    }
    public static void prettyPrint(String author, List<String> book){
        if(author.length() >15)
            System.out.println("Author: "+author + "\t Book(s): "+ book);
        else
            System.out.println("Author: "+author + "\t\t Book(s): "+ book);
    }
}












