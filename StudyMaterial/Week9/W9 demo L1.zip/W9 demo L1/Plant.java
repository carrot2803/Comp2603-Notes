public class Plant{// implements Comparable{
    private String name;
    private int cost;
    public Plant(String name){
        this.name = name;
        cost = (int)(new java.util.Random().nextDouble()*100);
    }
    public Plant(String name, int cost){
        this.name = name;
        this.cost = cost;
    }
    public int getCost(){return cost;}
    public String getName(){ return name;}
    public String toString(){
        return name + " $"+cost;
    }
    public boolean equals(Object obj){
        if (obj instanceof Plant){
             Plant p = (Plant) obj;
             return p.name.equals(this.name);
        }
        throw new IllegalArgumentException (
        "Object must be a plant for equality");
    }
    public int hashCode(){
        return name.hashCode();
    } 
    public int compareTo(Object obj){
        if (obj instanceof Plant){
             Plant p = (Plant) obj;
             return this.name.compareTo(p.name);
        }
        throw new ClassCastException(
        "Object must be a plant for comparison");
    }
}