//LAB 4

public class StudentApp {
	
    public static void main(String[] args){
    	Student s1 = new Student();
    	s1.setName("Beatrix Kiddo");
    	
    	Student s2 = new Student();
    	s2.setName("Dominic Toretto");
    	
    	System.out.println(s1.toString());
    	System.out.println(s2.toString());
    	
     }
}
