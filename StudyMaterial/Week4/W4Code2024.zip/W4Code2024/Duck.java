public class Duck extends Bird{
    private double weight;
    
    public Duck(String name){
        super(name);
        weight = 15;
    }
    public String toString(){
        String s = super.toString();
        s += " Weight: " + weight;
        return s;
    }
}



/*
 * 
 *  public Duck(String name){
        super(name);
    }
    public String getTitledName(){
        return "Sir " + name;
    }
 */