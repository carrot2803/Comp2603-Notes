public class Runner{
    public static void main(String[] args){
        Bird b1 = new Bird("Bord");
        System.out.println(b1.toString());
        Duck b2 = new Duck("Darfey");
        System.out.println(b2.toString());
        
    }
}


/*
 * 
 *  Bird b1 = new Bird("Duffiey");
        System.out.println(b1.toString());
        Duck b2 = new Duck("Darfey");
        System.out.println(b2.toString());
 */