public class Bird{
    private String name;
    
    public Bird(String name){
        this.name = name;
    }
    public  String toString(){
        return this.getClass().getSimpleName() +": "+ name;
    }
}







/*
 * protected String name;
    
    public Bird(String name){
        this.name = name;
    }
    
 */