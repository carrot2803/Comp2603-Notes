public class BlueMoscovy extends Moscovy{
    
}