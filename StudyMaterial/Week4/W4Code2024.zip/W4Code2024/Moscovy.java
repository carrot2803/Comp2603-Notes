public final class Moscovy extends Duck{
    public Moscovy(){
        super("Mosco");
    }
}