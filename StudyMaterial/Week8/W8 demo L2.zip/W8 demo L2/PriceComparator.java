import java.util.Comparator;
public class PriceComparator implements Comparator{
    public int compare(Object obj1, Object obj2){
        if(obj1 instanceof Plant && obj2 instanceof Plant){
            Plant p1 = (Plant)obj1;
            Plant p2 = (Plant)obj2;
            if (p1.getCost() == p2.getCost()) return 0;
            if (p1.getCost() > p2.getCost()) return 1;
            if (p1.getCost() < p2.getCost()) return -1;
        }
        throw new ClassCastException(
        "Objects must be plants for comparison");
    }
}