import java.util.HashSet;
import java.util.TreeSet;
public class Demo{
    public static void main(String[] args){
        Plant p1 = new Plant("Basil",20);
        Plant p2 = new Plant("Anise",25);
        Plant p3 = new Plant("Thyme",14);
        TreeSet<Plant> herbs = new TreeSet<>();
        herbs.add(p1);
        herbs.add(p2);
        herbs.add(p3);
        System.out.println(herbs);
        
        PriceComparator priceComp = new PriceComparator();
        TreeSet<Plant> herbsByCost = new TreeSet<>(priceComp);
        herbsByCost.addAll(herbs);
        System.out.println(herbsByCost);
    }
    
    
    
    public static void demoTreeSet(){
        TreeSet<String> books = new TreeSet<>();
        
        String b1 = "What the dog saw";
        String b2 = "Flowers for Algernon";
        String b3 = "How we got to now";
        
        books.add(b1);
        books.add(b2);
        books.add(b3);
        
        System.out.println(books);
    }
    
    
    public static void demoHashSet2(){
        Plant p1 = new Plant("Basil");
        Plant p2 = new Plant("Basil");
        Plant p3 = new Plant("Basil");
        HashSet<Plant> herbs = new HashSet<>();
        herbs.add(p1);
        herbs.add(p2);
        herbs.add(p3);
        System.out.println(herbs);
        System.out.println("["+p1.hashCode()+","
                              +p2.hashCode()+","
                              +p3.hashCode()+"]");
        
    }
    public static void demoHashSet(){
        HashSet<String> books = new HashSet<>();
        
        String b1 = "What the dog saw";
        String b2 = "Flowers for Algernon";
        String b3 = "How we got to now";
        
        books.add(b1);
        books.add(b2);
        books.add(b3);
        
        System.out.println(books);
        System.out.println("["+b2.hashCode()+","
                              +b1.hashCode()+","
                              +b3.hashCode()+"]");
        
    }
        
}
