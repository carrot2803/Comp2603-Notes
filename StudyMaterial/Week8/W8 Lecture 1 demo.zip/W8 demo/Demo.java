import java.util.Collection;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Vector;
import java.util.Iterator;

public class Demo{
    
    public static void main(String[] args){
        LinkedList<String> list  = new LinkedList<String>();
        String s1 = "Avoid the fog";
        String s2 = "Eat the frog";
        String s3 = "Feed the dog";
        list.add(s1);
        list.add(s2);
        list.add(s3);
        String s = list.get(2);
        
        Plant p1 = new Plant("Orchid");
        Plant p2 = new Plant("Rose");
        Plant p3 = new Plant("Sunflower");

        Vector<Plant> flowers  = new Vector<Plant>();
        flowers.add(p1);
        flowers.add(p2);
        flowers.add(p3);
        
        Iterator<Plant> iter = flowers.iterator();
        while(iter.hasNext()){
            Plant p = iter.next();
            System.out.println("From iterator: "+ p);
        }
        for(Plant p: flowers){
             System.out.println("From for loop: "+ p);
             flowers.remove(p3);
        }
        
        
        
        System.out.println("------------------");
        int roseIndex = flowers.indexOf(p2);
        
        Plant p = flowers.get(1);
        System.out.println(p);
        
        System.out.println("Rose index ="+ roseIndex);
        
        Plant pN = new Plant("Rose");
        int otherRoseIndex = flowers.indexOf(pN);
        System.out.println("Other Rose index ="+ otherRoseIndex);
   
        boolean hasSunFlower = flowers.contains(new Plant("Sunflower"));
        System.out.println("Has Sunflower  ="+ hasSunFlower);
        
    }
}








/*
 * Collection<Plant> plants;
        plants = new ArrayList<>();
        int numPlants = plants.size();
        ArrayList<Plant> newPlants = (ArrayList)plants;
        for (int i = 0 ; i < numPlants; i++){
            Plant p = newPlants.get(i);
        }
 * 
 */