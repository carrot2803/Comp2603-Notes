import java.util.ArrayList;

public class Week3Demo{
    public static void main(String[] args){  
        ArrayList<Publisher> publishers = new ArrayList<Publisher>();           
        Book b1 = new Book ("1984", 3767);
        Book b2 = new Book ("Dune", 8949);
        Book b3 = new Book ("Emma", 3323);
        Author a1 = new Author ("George Orwell", b1);
        Author a2 = new Author ("Frank Herbert", b2);
        Author a3 = new Author ("Jane Austin", b3);
        
        Publisher p = new Publisher();
        p.addBook(b1);
        p.addBook(b2);
        
        Publisher p2 = new Publisher();
        p2.addBook(b3);
       
        publishers.add(p);
        publishers.add(p2);
               
        System.out.println(publishers);       
    }
}







/*
 * 
 * 
 * 
  String s1 = "abc";
        String s2 = new String("abc");
        if (s1.equals(s2))// checks string characters; ignores location
            System.out.println("strings are equal");
        else
            System.out.println("strings are not equal");
        }
 * double x = 4.0;
        double w = Math.pow(2,2);
        if (x == w)// checks value at memory location
            System.out.println("variables are equal: "+ x +" = "+ w);
        else
            System.out.println("variables are not equal"+ x +" != "+ w);
        */ 