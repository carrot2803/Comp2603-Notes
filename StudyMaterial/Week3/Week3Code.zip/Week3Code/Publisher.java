import java.util.ArrayList;

public class Publisher{
    private ArrayList<Book> books;  
    public Publisher( ){
      books = new ArrayList<Book>();
    }
    public void addBook(Book b){
        books.add(b);
    }
    public String toString(){
        return "PUBLISHER " + books;
    }
}