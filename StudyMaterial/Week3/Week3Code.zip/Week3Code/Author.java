public class Author {
    private Book myBook;
    private String name;
    public Author (String name, Book book){
       this.name = name;
       myBook = book; 
    }
    public String toString( ){
        return "AUTHOR: "+ name + " " +  myBook.toString();
    }
}