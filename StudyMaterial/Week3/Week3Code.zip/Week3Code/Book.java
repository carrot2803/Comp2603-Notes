public class Book{ 
    private String title;
    private int ISBN;
    public Book(String title){
        this.title = title;
    }
    public Book(String title, int ISBN){
        this.title = title;
        this.ISBN = ISBN;
    }
    public String getTitle(){
        return title.toUpperCase();
    }
    public int getISBN(){
        return ISBN;
    }
    public String toString(){
        return "Book: " + getTitle();// +" " + getISBN();
    }
    
    public boolean equals(Object obj){
        // two books are equal if titles and ISBNs are equal
        Book incoming = (Book)obj; //Must cast
        if(this.title.equals(incoming.getTitle()) &&
           this.ISBN == incoming.getISBN())
          return true; 
        return false; 
    }
    
    
    
    
    
    
    //overloaded constructor
    public Book(int ISBN){
        //System.out.println("book overloaded constructor called");
        this.ISBN = ISBN;
    }
    
    /*public Author getAuthor(){
        return author;
    }
    public void setAuthor(Author author){
         this.author=author;
    }
    */
   
    public void setISBN(int ISBN){
        this.ISBN = ISBN;
    }
    
    /*
     * 
    
    private Author author;
    //System.out.println("book no-argument constructor called");
    public boolean equals(Object obj){
        // two books are equal if isbns are equal
        Book incoming = (Book)obj; //Must cast
        int b2ISBN = incoming.getISBN();
        //System.out.println("book object method called");
        if(this.ISBN ==  b2ISBN)
          return true; // when?
        return false; //when?
    }*/

}