public class Runner{
    
    public static void main(String[] args){
        Cat c = new Cat("Aarfield");
        System.out.println(c.toString());
        Lion lion = new Lion("Lofasa");
        System.out.println(lion.toString());
        lion.eat(c);
        System.out.println(lion.whatDidYouEat());
    }
}