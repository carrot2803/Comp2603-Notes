public class Cat{
  private String name;
  public Cat(String name){
        this.name = name;
    }
    
       
}



/*
 * 
 * 
 * 
 * public String toString(){
        return "Cat: "+ name;
 
 *  
      Cat c = new Cat("Aarfield");
        System.out.println(c);
        Lion lion = new Lion("Lewis");
        System.out.println(lion.toString()
 
    public Cat(String name){
        this.name = name;
    }
    
    public String toString(){
        return "Cat: "+ name;
    }
  
  
  
 */