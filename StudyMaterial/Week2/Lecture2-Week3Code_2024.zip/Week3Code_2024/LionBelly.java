import java.util.ArrayList;
public class LionBelly{
    private ArrayList<Object> meals;
    public LionBelly(Lion lion){
        meals = new ArrayList<Object>();
    }
    public void add(Object obj){
        meals.add(obj);
    }
    public String whatDoIcontain(){
        String mealDetails ="I ate: ";
        for(Object obj: meals)
             mealDetails += obj.toString() +" ";
        return mealDetails+ ". And it was delicious";
    }
    }