
public class Lion extends Cat{
    private LionBelly myBelly;
    
    public Lion(String name){
        super(name);
        myBelly = new LionBelly(this);
    }
    public void eat(Object food){
        myBelly.add(food);
    }
    public String whatDidYouEat(){
        return myBelly.whatDoIcontain();
    }
    
    
}




/*
 *
 import java.util.ArrayList;
 
 private ArrayList<Cat> dinner;
   public Lion(String name){
       super(name);
       dinner = new ArrayList<Cat>();
   }
    public void eat(Cat c){
        dinner.add(c);
    }
 *
 */