public class Cat{
    //State variables
    private String name;
    private double weight;
    private int age;
    private boolean hungry;
    private String[] favouriteFoods;
    
    //Constructor - Default No Argument
    public Cat( ){
        
    }
        // Constructor - One arg
    public Cat(String name){
        setName(name);
        weight = Math.round(new java.util.Random( ).nextDouble(25));
        age = (new java.util.Random( )).nextInt(30);
    }

    //Accessors
    public String getName( )    { return name;}
    public double getWeight( )  { return weight;}
    public int getAge( )        { return age;}
    public boolean getHungry( ) { return hungry;}
        
       public String toString( ){
        return getName( )+ " , " + getAge() +  " , " + getWeight( ) +  " , " + getHungry( );
    }

    
    
    
    
    public void setWeight(double weight){ 
        if(weight > 0 && weight < 25) // lbs
            this.weight = weight;
    }
    public void setAge(int age){ 
        if(age > 0 && weight < 30) 
            this.age = age;
    }
    public void setHungry(boolean hungry){
        this.hungry = hungry;
    }
        //Mutators
    public void setName(String name){ 
        if(name != null)
            this.name = name;
    }
    public void setName(String name, String title){ 
        if(name != null && title != null)
            this.name = title + " " + name;
    }
    public void setName(String name, String title, String suffix){ 
        if(name != null && title != null && suffix != null)
            this.name = title + " " + name + " " + suffix;
    }
 
} 