public class Runner{
    public static void main(String[] args){
        Cat cat1 = new Cat("Aarfield");
        Cat cat2 = new Cat("Heathcliff");
        
        String s1 = cat1.toString();
        String s2 = cat2.toString();
        
        System.out.println(s1);
        System.out.println(s2);
    
    }
}
         
        
        
        
        
/*        cat.setName("Aarfield");
        
        System.out.println(cat.getName() +" (via accessor)");
        //System.out.println(cat.name      +" (raw reference)"); <- NOT ALLOWED
        //cat.name = null; <- NOT ALLOWED
        System.out.println(cat.getName() +" (via accessor)");
        //System.out.println(cat.name      +" (raw reference)"); <- NOT ALLOWED
        
        System.out.println(cat.getName());
        cat.setName("Aarfield","Sir");
        System.out.println(cat.getName());
        cat.setName("Aarfield","Sir", "III");
        System.out.println(cat.getName());
    
        Cat cat1 = new Cat();
        System.out.println(cat1.getName());
        Cat cat2 = new Cat("Heathcliff");
        System.out.println(cat2.getName());
        */

        
        
        
       

 