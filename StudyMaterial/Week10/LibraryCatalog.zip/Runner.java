import java.util.*;

public class Runner{
    
    public static void main(String[] args){
        LibraryCatalog catalog= new LibraryCatalog();
        
        //Create Books
        Book b1 = new Book("1234", "Call of the Wild", new HashSet<>(Arrays.asList("Fiction", "Adventure")));
        Book b2 = new Book("5678", "The History of Mathematics", new HashSet<>(Arrays.asList("Non-Fiction", "Science", "Mathematics")));
        Book b3 = new Book("91011", "Journey to the Center of the Earth", new HashSet<>(Arrays.asList("Fiction", "Adventure", "Classic")));
        Book b4 = new Book("121314", "The Theory of Everything", new HashSet<>(Arrays.asList("Non-Fiction", "Science", "Physics")));
        Book b5 = new Book("151617", "Gardening for Beginners", new HashSet<>(Arrays.asList("Non-Fiction", "Hobby", "Gardening")));
        Book b6 = new Book("181920", "Mystery of the Haunted House", new HashSet<>(Arrays.asList("Fiction", "Mystery")));
        Book b7 = new Book("212223", "Introduction to Computer Science", new HashSet<>(Arrays.asList("Non-Fiction", "Technology", "Computer Science")));
        Book b8 = new Book("242526", "Mastering the Art of French Cooking", new HashSet<>(Arrays.asList("Non-Fiction", "Cooking", "Cultural")));
        Book b9 = new Book("272829", "The Space Odyssey", new HashSet<>(Arrays.asList("Fiction", "Science Fiction")));
        Book b10 = new Book("303132", "Poems from the Heart", new HashSet<>(Arrays.asList("Fiction", "Poetry")));
        
        catalog.addBook(b1);
        catalog.addBook(b2);
        catalog.addBook(b3);
        catalog.addBook(b4);
        catalog.addBook(b5);
        catalog.addBook(b6);
        catalog.addBook(b7);
        catalog.addBook(b8);
        catalog.addBook(b9);
        catalog.addBook(b10);
        
        //Find Book by Genre
        System.out.println("Fiction: " + catalog.findBooksByGenre("Fiction"));
        System.out.println("Non-Fiction: " + catalog.findBooksByGenre("Non-Fiction"));
        System.out.println("Adventure: " + catalog.findBooksByGenre("Adventure"));
        
        //Get Unique Genre
        System.out.println("Unique Genres: "+ catalog.getUniqueGenres()); 
        
    }
}