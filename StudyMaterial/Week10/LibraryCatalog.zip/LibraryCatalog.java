import java.util.*;

public class LibraryCatalog{
    private Map<String, Book> books = new HashMap<>();
    private Map<String, Set<String>> booksByGenre= new HashMap<>();
    
    //Adds new book to catalog
    public void addBook(Book book){
        //Add book to the books map
        books.put(book.getID(), book);
        
        //Update the booksByGenre map
        for (String genre: book.getGenres()){
            //If it is that a genre does not exist, create a new hashset for it
            booksByGenre.putIfAbsent(genre, new HashSet<>());
            
            //Add the book's ID to the set of IDs for this genre 
            booksByGenre.get(genre).add(book.getID());
        }
    }
    
    //Returns a list of book titles belonging to a given genre
    public List<String> findBooksByGenre(String genre){
        List<String> titles= new ArrayList<>();
        Set<String> bookIDs= booksByGenre.get(genre);
        
        if(bookIDs != null){
            for (String id : bookIDs){
                titles.add(books.get(id).getTitle());
            }
        }
        return titles;
    }
    
    public Set<String> getUniqueGenres(){
        return new HashSet<>(booksByGenre.keySet());
    }
    
}