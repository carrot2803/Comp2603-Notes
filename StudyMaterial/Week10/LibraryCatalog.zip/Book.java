import java.util.*;

public class Book{
    private String ID;
    private String title;
    private Set<String> genres;
    
    //Constructor
    public Book(String id, String title, Set<String> genres){
        this.ID= id;
        this.title= title;
        this.genres= new HashSet<>(genres);
    }
    
    //Accessors
    public String getID(){return this.ID;}
    public String getTitle(){return this.title;}
    public Set<String> getGenres(){return new HashSet<>(genres);} // returns a copy to maintain ecapsulation
    
    //Modifers
    public void setID(String ID){this.ID=ID;}
    public void setTitle(String title){ this.title=title;}
    public void setGenres(Set<String> genres){this.genres= new HashSet<>(genres);}
    
    //Overrides
    @Override
    public boolean equals(Object obj){
        if(obj instanceof Book){
            Book b1= (Book) obj;
            if(this.ID==b1.getID()){
                return true;
            }
        }
        throw new ClassCastException();
    }
        
    
    @Override
    public int hashCode(){
        return Objects.hash(ID);
    }
}