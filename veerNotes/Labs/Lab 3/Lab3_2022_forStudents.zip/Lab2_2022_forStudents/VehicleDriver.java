public class VehicleDriver {
    private String name;
    
    public VehicleDriver(String name){
        this.name = name;
    }
    
    public String getName(){
        return name;
    }
}
