import java.util.Random;

public class Passenger {
  private String passportNumber;
  private String firstName;
  private String lastName;
  private String flightNo;
  private int numLuggage;
  private char cabinClass;
  
  // Initialises the state of a Passenger object
  public Passenger(String passportNumber, String firstName, String lastName, String flightNo) {
    this.passportNumber = passportNumber;
    this.firstName = firstName;
    this.lastName = lastName;
    this.flightNo = flightNo;
    assignRandomNumLuggage();
    assignRandomCabinClass();
  }
  
  // Assigns random number of luggage
  private void assignRandomNumLuggage() {
    Random rand = new Random();
    this.numLuggage = rand.nextInt(4);
  }

  // Sets the cabinClass variable to a random cabin class variable using switch statements
  // https://docs.oracle.com/javase/tutorial/java/nutsandbolts/switch.html
  private void assignRandomCabinClass() {
    Random rand = new Random();
    int randomNum = rand.nextInt(4);
    switch (randomNum) {
      case 0:
        this.cabinClass = 'F';
        break;
      case 1:
        this.cabinClass = 'B';
        break;
      case 2:
        this.cabinClass = 'P';
        break;
      case 3:
        this.cabinClass = 'E';
        break;
  }
  }
  
  // Accessors
  public String getPassportNumber() {
    return passportNumber;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public String getFlightNo() {
    return flightNo;
  }

  public int getNumLuggage() {
    return numLuggage;
  }

  public char getCabinClass() {
    return cabinClass;
  }

  public String toString() {
    return "PP NO. " + passportNumber + " NAME: " + firstName.substring(0, 1) + "." + lastName + " NUMLUGGAGE: " + numLuggage + " CLASS: " + cabinClass;
  }
} 