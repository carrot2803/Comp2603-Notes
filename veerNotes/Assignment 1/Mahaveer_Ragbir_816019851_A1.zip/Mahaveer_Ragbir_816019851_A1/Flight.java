// import java.time.LocalDateTime;

// public class Flight {
// private String flightNo;
// private String destination;
// private String origin;
// private LocalDateTime flightDate;
// private LuggageManifest manifest;

// public Flight(String flightNo, String destination, String origin,
// LocalDateTime flightDate) {
// this.flightNo = flightNo;
// this.destination = destination;
// this.origin = origin;
// this.flightDate = flightDate;
// this.manifest = new LuggageManifest();
// }

// // checks luggage based on flight number and adds to the luggage manifest
// // returns "Invalid Flight" if wrong FlightNo.
// public String checkInLuggage(Passenger p) {
// if (this.flightNo.equals(p.getFlightNo())) {
// String output;
// output = manifest.addLuggage(p, this);
// // return "Luggage added to flight";
// return output;
// } else
// return "Invalid flight";
// }

// public String printLuggageManifest() {
// return manifest.toString();
// }

// // determines allowed luggage based on class using switch statements
// // https://docs.oracle.com/javase/tutorial/java/nutsandbolts/switch.html
// public int getAllowedLuggage(char cabinClass) {
// switch (cabinClass) {
// case 'F':
// return 3;
// case 'B':
// return 2;
// case 'P':
// return 1;
// case 'E':
// return 0;
// default:
// return 0;
// }
// }

// // Accessors
// public String getFlightNo() {
// return flightNo;
// }

// public void setFlightNo(String flightNo) {
// this.flightNo = flightNo;
// }

// public String getDestination() {
// return destination;
// }

// public void setDestination(String destination) {
// this.destination = destination;
// }

// public String getOrigin() {
// return origin;
// }

// public void setOrigin(String origin) {
// this.origin = origin;
// }

// public LocalDateTime getFlightDate() {
// return flightDate;
// }

// public void setFlightDate(LocalDateTime flightDate) {
// this.flightDate = flightDate;
// }

// public LuggageManifest getManifest() {
// return manifest;
// }

// public void setManifest(LuggageManifest manifest) {
// this.manifest = manifest;
// }

// public String toString() {
// return flightNo + " DESTINATION: " + destination + " ORIGIN: " + origin + " "
// + flightDate + "\n";
// }
// }
