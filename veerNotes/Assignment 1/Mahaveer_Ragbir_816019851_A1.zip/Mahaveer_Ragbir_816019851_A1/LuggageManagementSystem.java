import java.time.LocalDateTime;
import java.util.Scanner;
import java.io.File;

public class LuggageManagementSystem {
    public static void main(String[] args) {
        LocalDateTime d = LocalDateTime.of(2023, 1, 23, 10, 00, 00);

        try {
            Scanner sc = new Scanner(new File("passenger.txt"));
            String data = "";
            String[] pps = new String[25];
            String[] firstNames = new String[25];
            String[] lastNames = new String[25];
            String[] passFlightNo = new String[25];
            Passenger p;

            while (sc.hasNext()) {
                for(int i = 0; i < Integer.MAX_VALUE; i++){
                p = new Passenger(pps[i] = sc.next(), firstNames[i] = sc.next(), lastNames[i] = sc.next(),
                        passFlightNo[i] = sc.next());
                f = new Flight(passFlightNo[i], dest[i], origin[i], d);
                System.out.println(p);
            }

        } catch (Exception e) {
        }

        try {
            Scanner sc2 = new Scanner(new File("flights.txt"));
            String data2 = "";
            String[] flightNo = new String[25];
            String[] dest = new String[25];
            String[] origin = new String[25];
            Flight f;

            while (sc2.hasNext()) {
                f = new Flight(flightNo[i] = sc2.next(), dest[i] = sc2.next(), origin[i] = sc2.next(), d);
                // System.out.println(f.checkInLuggage(p));
                // System.out.println(f.printLuggageManifest());

            }
        } catch (Exception e) {
        }

        // You are required to create Flights and passengers from file
        LocalDateTime d = LocalDateTime.of(2023, 1, 23, 10, 00, 00);
        Flight yyz = new Flight("BW600", "POS", "YYZ", d);

        System.out.println(yyz);
        Passenger p;
        String[] pps = { "TA890789", "BA321963", "LA445241" };
        String[] firstNames = { "Joe", "Lou", "Sid" };
        String[] lastNames = { "Bean ", " Deer", "Hart" };

        for (int i = 0; i < 3; i++) {
            p = new Passenger(pps[i], firstNames[i], lastNames[i], "BW600");
            System.out.println(p);
            System.out.println(yyz.checkInLuggage(p));

        }
        System.out.println(yyz.printLuggageManifest());
    }

}
