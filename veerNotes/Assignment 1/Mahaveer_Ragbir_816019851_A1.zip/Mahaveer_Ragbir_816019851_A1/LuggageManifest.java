// import java.util.ArrayList;

// public class LuggageManifest {
// private ArrayList<LuggageSlip> slips;

// public LuggageManifest() {
// this.slips = new ArrayList<LuggageSlip>();
// }

// public ArrayList<LuggageSlip> getSlips() {
// return slips;
// }

// // adds luggage by retrieving allowed pieces vs excess to be used later on
// public String addLuggage(Passenger p, Flight f) {
// int numAllowedPieces = f.getAllowedLuggage(p.getCabinClass());
// int numPieces = p.getNumLuggage();
// int excess = numPieces - numAllowedPieces;
// double cost = 0;
// if (numPieces > numAllowedPieces) {
// cost = getExcessLuggageCost(numPieces, numAllowedPieces);

// }
// if (excess > 0) {
// for (int i = 0; i < numPieces; i++) {
// LuggageSlip slip = new LuggageSlip(p, f, Double.toString(cost));
// slips.add(slip);
// }
// }
// return "Luggage added successfully. Cost of excess luggage: $" + cost + "\n";
// }

// // calculates the excess luggage cost
// // System.out.println(yyz.printLuggageManifest());
// public double getExcessLuggageCost(int numPieces, int numAllowedPieces) {
// return (numPieces - numAllowedPieces) * 35.00;
// }

// // calculates the excess luggage cost by passenger (checks the if there's
// record
// // of the owner's passport number and gets label if there is)
// public String getExcessLuggageCostByPassenger(String passportNumber) {
// double totalCost = 0;
// for (LuggageSlip slip : slips) {
// if (slip.getOwner().getPassportNumber().equals(passportNumber)) {
// totalCost += this.getExcessLuggageCost(slip.getOwner().getNumLuggage(),
// Flight.getAllowedLuggage(slip.getOwner().getCabinClass()));
// if (!slip.getLabel().equals("")) {
// return slip.getLabel();
// }
// }
// }
// // if (totalCost > 0) {
// // return "Total cost of excess luggage for passenger " + passportNumber + ":
// $"
// // + totalCost;
// // }
// return "No cost";
// }

// public String toString() {
// String output = "\nLUGGAGE MANIFEST\n";
// for (LuggageSlip slip : slips) {
// output += slip.toString() + "\n";
// }
// return output;
// }
// }
