public class LuggageSlip {
  private static int luggageSlipIDCounter = 1;
  private Passenger owner;
  private String luggageSlipID;
  private String label;

  // Base Contructor, initialises all state using input parameteres and sets label
  // to empty String
  public LuggageSlip(Passenger p, Flight f) {
    this.owner = p;
    this.luggageSlipID = f.getFlightNo() + "_" + p.getLastName() + "_" + luggageSlipIDCounter++;
    this.label = "";
  }

  // Overloaded constructor, where all input parameters, inclusive of label are
  // initialised
  public LuggageSlip(Passenger p, Flight f, String label) {
    this.owner = p;
    this.luggageSlipID = f.getFlightNo() + "_" + p.getLastName() + "_" + luggageSlipIDCounter++;
    this.label = label;
  }

  // Accessors (Simple check for Owner existence)
  public boolean hasOwner(String passportNumber) {
    return this.owner.getPassportNumber().equals(passportNumber);
  }

  public Passenger getOwner() {
    return owner;
  }

  public String getLuggageSlipID() {
    return luggageSlipID;
  }

  public String getLabel() {
    return label;
  }

  public String toString() {
    return luggageSlipID + " " + owner.toString() + " " + label + "\n";
  }

  public void add(LuggageSlip luggageSlip) {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'add'");
  }
}