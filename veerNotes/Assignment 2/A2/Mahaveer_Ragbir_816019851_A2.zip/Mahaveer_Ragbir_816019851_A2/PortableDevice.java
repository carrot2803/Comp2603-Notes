import java.io.*;
import java.util.*;

public interface PortableDevice extends Device {
    
//public boolean isOn();
}