/*
 * 
/**
 *
 * @author phaedramohammed
 * @edited by: 
 */
import java.util.ArrayList;
import java.util.Random;

public class PaymentPortalApplication {
    public static void main(String[] args){
        PaymentPortal lennysPaymentPortal = new PaymentPortal();
        lennysPaymentPortal.setVisible(true);
    }

}
