public class Postgraduate extends Student{

public String supervisor;
public String thesisTitle;
public String status;

public Postgraduate(String name, String supervisor,String thesisTitle){
super(name);
this.supervisor = supervisor;
this.thesisTitle = thesisTitle;
}

public void setStatus(){
this.status ="full-time";
}

public void setStatus(String s){
this.status = s;
}

public void calculateFees(){
if(status.equals("part-time")){
   setFees(1325);
}
else{
 setFees(2650);
}
}

public String toString(){
    String output = super.toString() + " Supervisor:" + supervisor + " Thesis Title:" + thesisTitle;
    return output;
}
}