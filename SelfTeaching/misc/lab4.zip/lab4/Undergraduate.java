public class Undergraduate extends Student{

    private String minor;
    private String major;
    private int credit;
    
    public String getMinor(){
    return this.minor;
    }
    
    public String getMajor(){
    return this.major;
    }
    
    public int getCredit(){
    return this.credit;
    }
    
    public void setMinor(String minor){
    this.minor = minor;
    }
    
    public void setMajor(String major){
    this.major = major;
    }
    
    public void setCredit(int credit){
    this.credit = credit;
    }
    
    //constructor
    public Undergraduate(){
    
    }
    
    public void calculateFees(){
    double fees = getCredit() * 200;
    setFees(fees);
    }
    
    public String toString(){
        String intial = super.toString();
        String output = intial + " Major:" + getMajor() + " Minor:" + getMinor() + " Credit:" + getCredit();
        return output;
    }
}