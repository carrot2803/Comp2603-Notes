//LAB 5 

public class StudentApp {
    
    public static void main(String[] args){
        Student s1 = new Student();
        s1.setName("Beatrix Kiddo");
        
        Student s2 = new Student();
        s2.setName("Dominic Toretto");
        
        System.out.println(s1.toString());
        System.out.println(s2.toString());
        
        Undergraduate u1 = new Undergraduate();
        u1.setName("Barry Allen");
        //u2.setID(30);
        u1.setMajor("Forensics");
        u1.setMinor("Athletics");
        u1.setCredit(25);
        
        
        Undergraduate u2 = new Undergraduate();
        u2.setName("John Rambo");
        //u2.setID(40);
        u2.setMajor("Conflict Analysis");
        u2.setMinor("International Affairs");
        u2.setCredit(25);
        
        Undergraduate u3 = new Undergraduate();
        u3.setName("Ellen Ripley");
        //u2.setID(50);
        u3.setMajor("Astrobiology");
        u3.setMinor("Conflict Analysis");
        u3.setCredit(20);
        
        System.out.println(u1);
        System.out.println(u2);
        System.out.println(u3);
        
        Postgraduate p1 = new Postgraduate("John McClain","Prof.Asp Pirin","How to die hard");
        p1.setStatus("full-time");
        p1.calculateFees();
        Postgraduate p2 = new Postgraduate("Brian Mills","Dr. No Kia","Mobile Usage Patterns in Hostage Situations");
        p2.setStatus("part-time");
        System.out.println(p1);
        System.out.println(p2);
     }
}
