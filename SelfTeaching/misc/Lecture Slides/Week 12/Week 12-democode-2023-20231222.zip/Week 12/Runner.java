import java.util.*;

public class Runner{
    
    public static void main(String[] args){
       //Maps use key, value pair
       //Plant: (key=Plant)->(value=Grove)
       
       /* Suppose we want to model a farm that has several groves,
        * each containing numerous plants. Each grove however only
        * grows one type of plant (fruit trees).
        */
       //simple create
       TreeMap<Plant,Grove> farm = new TreeMap<Plant,Grove>();
       
       
       //create with comparator
       //PlantComparator comparator = new PlantComparator();
       //PriceComparator priceComparator = new PriceComparator();
       //TreeMap<Plant,Grove> farm = new TreeMap<Plant,Grove>(comparator);
       //TreeMap<Plant,Grove> farm = new TreeMap<Plant,Grove>(priceComparator);
       
        //create a few Plant objects
       Plant p1 = new Plant("Pineapple Orange");
       Plant p2 = new Plant("Blood Orange");
       Plant p3 = new Plant("Navel Orange");
       Plant p4 = new Plant("Valencia Orange");
       Plant p5 = new Plant("Tangerine Citrus");
       Plant p6 = new Plant("Clementine");
       
       //add (key,value) pair
       String groveName = p1.getName(); //returns Pineapple Orange
       Grove g100 = new Grove(groveName); //creates Grove with supplied name
       farm.put(p1,g100); //inserting into TreeMap. Plant is Comparable
       
       farm.put(p2, new Grove(p2.getName()));
       farm.put(p3, new Grove(p3.getName()));
       farm.put(p4, new Grove(p4.getName()));
       farm.put(p5, new Grove(p5.getName()));
       farm.put(p6, new Grove(p6.getName()));
       
       System.out.println(farm);
       
       //traverse 
       Set<Plant> plants = farm.keySet();
       //System.out.println("KEYS:");
      // printCollection(plants);
       System.out.println("MAP:");
       printMapCollection(plants, farm);
         
       //find (value)
       Grove bloodOrangeGrove = farm.get(new Plant("Blood Orange"));
       System.out.println(bloodOrangeGrove);
      
       //find (key)  - Locate the key for value Grove g100
       Set<Plant> keys = farm.keySet();
       Plant grove100Key = null;
       Iterator<Plant> iter = keys.iterator();
       while(iter.hasNext() && grove100Key == null){
           Plant key = iter.next();
           if(farm.get(key).equals(g100))
            grove100Key = key;
       }
       System.out.println(grove100Key);
        System.out.println("-->"+new Plant("Pineapple Orange"));
       //update
       
       //replace
       
       //delete
       
  
       
       
    }
      private static void printCollection(Collection<Plant> list){
        java.util.Iterator<Plant> iter = list.iterator();
        while(iter.hasNext()){
            Plant p = iter.next();
            System.out.println(p);
        }
    }
    
    private static void printMapCollection(Collection<Plant> list, Map<Plant,Grove> map){
        java.util.Iterator<Plant> iter = list.iterator();
        while(iter.hasNext()){
            Plant plant = iter.next();
            Grove grove = map.get(plant);
            System.out.println(plant + "\t=> " + grove);
        }
    }
    
    
    
    private static HashSet<Plant> createFlowers(){
        HashSet<Plant> flowers = new HashSet<>();
        for(int i=0; i<5; i++){
            Plant p = new Plant("Petunia");
            flowers.add(p);
        }
        return flowers;
    }
    
    private static TreeSet<Plant> createHardWoods(){
        TreeSet<Plant> hardWoods = new TreeSet<Plant>();
        hardWoods.add(new Plant("Poui"));
        hardWoods.add(new Plant("Teak"));
        hardWoods.add(new Plant("Mora"));
        hardWoods.add(new Plant("PurpleHeart"));
        return hardWoods;
    }
    
    private static HashMap<String,Plant> createHerbs(){

       //create
       HashSet<Plant> herbs1 = new HashSet<Plant>();
       HashMap<String,Plant> herbs = new HashMap<String,Plant>();
      HashMap<Integer,Plant> herbs2 = new HashMap<Integer,Plant>();
      
       //add
       Plant p1= new Plant("Basil");
       Plant p2= new Plant("Lavender");
       Plant p3= new Plant("Oregano");
       Plant p4= new Plant("Chadon Beni");//Shadow Benny
       Plant p5= new Plant("Chive");
       Plant p6= new Plant("Thyme");
       
       herbs1.add(p1);
       herbs.put(p1.getName(), p1);
       herbs.put(p2.getName(), p2);
       herbs.put(p3.getName(), p3);
       herbs.put(p4.getName(), p4);
       herbs.put(p5.getName(), p5);
       herbs.put(p6.getName(), p6);
       System.out.println(herbs);
       
       //find
       Plant chive  = herbs.get("Chive");
       if(chive != null)
            System.out.println("Found : "+ chive);
            
       //update value
       p4.setPrice(5);
       herbs.put("Chadon Beni", p4);
       System.out.println(herbs);
       
       //replace value
       Plant p7 = new Plant("Shadow Benny");
       String key = "Chadon Beni";
       
       Plant chadonBeniShadowPlant = new Plant("Chadon Beni");
       chadonBeniShadowPlant.setPrice(5);
       
       boolean success = herbs.replace(key,chadonBeniShadowPlant,p7);
       if(success) 
            System.out.println(herbs);
       else
            System.out.print("replace failed. Did not find plant");
      
       //delete - remove value
       Plant lavender = herbs.remove("Lavender");
       System.out.println(herbs);
       Set<String> keys = herbs.keySet();
       System.out.println("keys:" + keys);
       
       //delete - remove key and value
       success = herbs.remove("Oregano",p3);
       System.out.println(herbs);
       keys = herbs.keySet();
       System.out.println("keys:" + keys);
       
       //traverse - values
       Collection<Plant> herbPlants = herbs.values();
       System.out.println(herbPlants);
       Iterator<Plant> iter = herbPlants.iterator();
       int plantNum=0;
       while(iter.hasNext()){
           System.out.print(++plantNum + " " + iter.next() + "  ");
           
       }
      
       //sort
       ArrayList<Plant> herbPlantList = new ArrayList<Plant>(herbPlants);
       System.out.println("\nUnsorted: " + herbPlantList);
       Collections.sort(herbPlantList);
       System.out.println("Sorted: " +herbPlantList);
       
       return herbs;
    }
    
  

    
}
    

