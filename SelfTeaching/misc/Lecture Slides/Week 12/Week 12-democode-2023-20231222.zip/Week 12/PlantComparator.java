import java.util.Comparator;

public class PlantComparator implements Comparator{

 public int compare(Object obj1, Object obj2){
        if( (obj1 instanceof Plant) && (obj2 instanceof Plant)){
            Plant p1 = (Plant)obj1;
            Plant p2 = (Plant)obj2;
            return p1.getName().compareTo(p2.getName());
        }
        throw new IllegalArgumentException();
    }
}

