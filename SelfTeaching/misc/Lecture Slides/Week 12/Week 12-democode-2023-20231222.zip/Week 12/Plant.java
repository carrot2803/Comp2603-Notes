
public class Plant implements Comparable{
    private String name;
    private int price;
    private int ID;
    
    public Plant(String n){
        name = n;
        price = (int)(new java.util.Random().nextDouble()*100);
    }
    public int getPrice(){
        return price;
    }
    public void setPrice(int price){
        this.price = price;
    }
    public String getName(){
        return name;
    }
    
    public String toString(){
        return "Plant: " +name + "\t $"+ price;
    }
    
    public int compareTo(Object obj){
        if(obj instanceof Plant){
            Plant p = (Plant) obj;
            return p.name.compareTo(this.name);
        }
        throw new IllegalArgumentException();
    }
    
    public boolean equals(Object obj){
        if(obj instanceof Plant){
            Plant incomingPlant = (Plant) obj;
            String plantName = incomingPlant.name;
            if(this.name.equals(plantName))
                return true;
        }
        return false; 
    }

}