/**This class models a Plant that has a name and identifier
   */
public class Plant {
    private String name;

    public Plant(String name){
        this.name = name;
     }
    public String getName(){ 
        return name;
    }
    public String toString(){
        return getName();
    }
    
    public boolean equals(Object obj){
        if(obj instanceof Plant){
            Plant incomingPlant = (Plant)obj;
            return this.name.equals(incomingPlant.name);
        }
        throw new IllegalArgumentException("not a plant");
    }
     public int hashCode(){
        return name.hashCode();
     }
   
}









/*
   public boolean equals(Object obj){
        if (obj instanceof Plant){
            Plant p = (Plant)obj;
            return p.getName().equals(this.getName());
        }   
        return false;
    }
    
    */