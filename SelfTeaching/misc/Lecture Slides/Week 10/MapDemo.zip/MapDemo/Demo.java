import java.util.*;

public class Demo{
    
    public static void main(String[] args){
        Map<String,Plant> plants  = getMap();
        Map<Plant, String> plantNames = getAnotherMap();
           Plant aloe = new Plant("Aloe");
           plantNames.put(aloe,"Aloe");
        
        
        
        
     
         System.out.println("original aloe hash code" + aloe.hashCode());
       
        Plant basil = new Plant("Aloe");
        
        plants.put("Aloe",aloe);
        plants.put("Basil",basil);
        
        //Chamomile
        plants.put("Chamomile", new Plant("Chamomile"));
        
        System.out.println("-------LIST OF PLANTS-----");
        Collection<Plant> plantValues = plants.values();
        for(Plant p: plantValues){
            System.out.println(p.hashCode());
        }
        System.out.println("----------------");
        
        Plant aloeValue;
        aloeValue = plants.get("Aloe");
        System.out.println(aloeValue);
        
        System.out.println("----------------");
        Plant otherAloe = new Plant("Aloe");
        System.out.println("Other aloe hash code" + otherAloe.hashCode());
        System.out.println(otherAloe.equals(aloeValue));
           
         
        
        
        
        
        /*plants.add(new Plant("Coconut"));
        plants.add(new Plant("Pine"));
        plants.add(new Plant("Bamboo"));
        plants.add(new Plant("Hibiscus"));
        
        /*for(Plant p: plants){
            System.out.println(p);
        }
           Plant hp = new Plant("Hibiscus");
        System.out.println(hp);
        */
        
     /*
        if(plants.containsKey(aloe)){
            System.out.println("ALOE found");
        }
        else
            System.out.println("ALOE not found");
        */
        
    }
    
    public static Map<String, Plant> getMap(){
        return new HashMap<String,Plant>(); 
    }
     public static Map<Plant, String> getAnotherMap(){
        return new HashMap<Plant,String>(); 
    }
}