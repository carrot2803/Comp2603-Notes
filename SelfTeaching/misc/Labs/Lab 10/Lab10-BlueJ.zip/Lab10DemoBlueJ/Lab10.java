
 

/**
 * @author phaedramohammed
 */
public class Lab10 {

    // Main method 
    public static void main(String[] args) {
        GreenhouseGUI gui = new GreenhouseGUI();
        gui.setVisible(true);        
    }
    
}
